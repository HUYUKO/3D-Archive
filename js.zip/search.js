!(function($) {
    "use strict";

        $(window).on('load', function() {
        var portfolioIsotope = $('.portfolio-container').isotope({
            layoutMode: 'fitRows'
        });

        $('#portfolio-flters li').on('click', function() {
            $("#portfolio-flters li").removeClass('filter-active');
            $(this).addClass('filter-active');

            portfolioIsotope.isotope({
            filter: $(this).data('filter')
            });
        });
        $(document).ready(function() {
        $('.venobox').venobox();
        });
    });
})(jQuery);

    function enterSearch() {
        if(event.keyCode == 13){
            myFunction();  // 실행할 이벤트
        }
    }
    function myFunction() {
        var x = document.getElementById("value").value;

        if(x == "천안" || x == "천안시"){ window.location.href = "ca.html"; }
        else if(x == "자유" || x == "자유시장길" || x == "천안시장" || x == "시장" || x == "자유시장"){ window.location.href = "ca_free.html"; }
        else if(x == "벽돌" || x == "공장" || x == "벽돌폐공장" || x == "폐공장" || x == "천안공장"){ window.location.href = "ca_block.html"; }

        if(x == "공주" || x == "공주시"){ window.location.href = "gj.html"; }
        else if(x == "한옥" || x == "한옥마을" || x == "공주한옥마을" || x == "공주한옥"){ window.location.href = "gj_krhouse.html"; }
        else if(x == "공산" || x == "공산성" || x == "공주공산성" || x == "공주사극" || x == "공주성"){ window.location.href = "gj_gong.html"; }
        else if(x == "가가" || x == "책방" || x == "가가책방" || x == "무인책방" || x == "공주책방"){ window.location.href = "gj_gaga.html"; }

        if(x == "보령" || x == "보령시"){ window.location.href = "br.html"; }
        else if(x == "상화원" || x == "상화" || x == "보령상화원" || x == "보령정원"){ window.location.href = "br_sang.html"; }
        else if(x == "충청수영성" || x == "보령수영성" || x == "수영성" || x == "보령수영" || x == "충청"){ window.location.href = "br_css.html"; }

        if(x == "아산" || x == "아산시"){ window.location.href = "as.html"; }
        else if(x == "포장마차" || x == "포차거리" || x == "아산포장마차" || x == "포장" || x == "골목" || x == "포장마차골목" || x == "포장마차거리"){ window.location.href = "as_pojang.html"; }
        else if(x == "코미디홀" || x == "아산코미디" || x == "코미디" || x == "공연장" || x == "아산공연장"){ window.location.href = "as_comic.html"; }

        if(x == "서산" || x == "서산시"){ window.location.href = "ss.html"; }
        else if(x == "계암" || x == "계암고택" || x == "고택" || x == "서산고택" || x == "서산계암고택"){ window.location.href = "ss_gotak.html"; }
        else if(x == "간월" || x == "간월암" || x == "서산간월암" || x == "서산섬" || x == "간월도리"){ window.location.href = "ss_gan.html"; }
        else if(x == "목장" || x == "한우목장" || x == "서산목장" || x == "벚꽃명소"){ window.location.href = "ss_sosan.html"; }

        if(x == "논산" || x == "논산시"){ window.location.href = "ns.html"; }
        else if(x == "돈암서원" || x == "돈암" || x == "서원" || x == "논산서원"){ window.location.href = "ns_don.html"; }
        else if(x == "미내다리" || x == "미내" || x == "다리" || x == "논산다리" || x == "논산미내다리"){ window.location.href = "ns_mine.html"; }
        else if(x == "강경역사관" || x == "강경" || x == "역사관" || x == "한일은행" || x == "논산역사관"){ window.location.href = "ns_gang.html"; }

        if(x == "계룡" || x == "계룡시"){ window.location.href = "gr.html"; }
        else if(x == "오후의산책" || x == "오후" || x == "산책" || x == "논산오후" || x == "논산카페"){ window.location.href = "gr_after.html"; }
        else if(x == "입압저수지" || x == "저수지" || x == "계룡저수지" || x == "입암리저수지"){ window.location.href = "gr_ipam.html"; }

        if(x == "당진" || x == "당진시"){ window.location.href = "dj.html"; }
        else if(x == "면천농협창고" || x == "면천농협" || x == "농협창고" || x == "당진창고" || x == "면천" || x == "창고"){ window.location.href = "dj_nh.html"; }
        else if(x == "아미미술관" || x == "아미" || x == "미술관" || x == "당진아미" || x == "당진미술관"){ window.location.href = "dj_army.html"; }
        
        if(x == "금산" || x == "금산군"){ window.location.href = "gs.html"; }
        else if(x == "지구별그림책마을" || x == "지구별" || x == "그림책마을" || x == "그림책" || x == "금산그림" || x == "동화마을"){ window.location.href = "gs_earth.html"; }
        else if(x == "태고사" || x == "불교" || x == "금산절" || x == "절"){ window.location.href = "gs_tego.html"; }

        if(x == "부여" || x == "부여군"){ window.location.href = "by.html"; }
        else if(x == "이안당" || x == "부여한옥" || x == "이안"){ window.location.href = "by_ian.html"; }
        else if(x == "반교리돌담마을" || x == "반교리" || x == "돌담마을" || x == "반교" || x == "돌담" || x == "부여마을" || x == "마을"){ window.location.href = "by_ban.html"; }

        if(x == "서천" || x == "서천군"){ window.location.href = "sc.html"; }
        else if(x == "판교마을" || x == "서천판교" || x == "판교" || x == "판교역"){ window.location.href = "sc_pan.html"; }
        else if(x == "장항송림산림욕장" || x == "장항송림" || x == "산림욕장" || x == "서천산림욕장" || x == "산책" || x == "산책로" || x == "장항"){ window.location.href = "sc_jang.html"; }
        else if(x == "홍원항" || x == "홍원" || x == "항구" || x == "서천항" || x == "서천항구" || x == "서천홍원항"){ window.location.href = "sc_hong.html"; }

        if(x == "청양" || x == "청양군"){ window.location.href = "cy.html"; }
        else if(x == "춘소커피" || x == "춘소" || x == "커피" || x == "청양커피" || x == "청양카페" || x == "청양춘소"){ window.location.href = "cy_chun.html"; }
        else if(x == "청남중학교" || x == "중학교" || x == "청양중학교" || x == "청남" || x == "학교"){ window.location.href = "cy_middle.html"; }

        if(x == "홍성" || x == "홍성군"){ window.location.href = "hs.html"; }
        else if(x == "홍성폐차장" || x == "폐차장" || x == "폐차" || x == "자동차" || x == "홍성폐차"){ window.location.href = "hs_car.html"; }
        else if(x == "홍주읍성" || x == "읍성" || x == "홍주성곽" || x == "홍성읍성"){ window.location.href = "hs_wall.html"; }
        else if(x == "속동전망대" || x == "속동" || x == "전망대" || x == "홍성전망대"){ window.location.href = "hs_sock.html"; }

        if(x == "예산" || x == "예산군"){ window.location.href = "ys.html"; }
        else if(x == "도중도" || x == "예산도중도" || x == "윤봉길" || x == "생가"){ window.location.href = "ys_dodo.html"; }
        else if(x == "의좋은형제공원" || x == "의좋은형제" || x == "형제공원" || x == "공원" || x == "예산공원"){ window.location.href = "ys_brother.html"; }

        if(x == "태안" || x == "태안군"){ window.location.href = "ta.html"; }
        else if(x == "갱지동굴" || x == "갱지" || x == "동굴" || x == "태안동굴"){ window.location.href = "ta_gdong.html"; }
        else if(x == "운여해변" || x == "운여" || x == "해변" || x == "태안해변"){ window.location.href = "ta_ubeach.html"; }
        else if(x == "갈음이해수욕장" || x == "갈음이" || x == "해수욕장" || x == "태안해수욕장"){ window.location.href = "ta_gbeach.html"; }

        if(x == "근대현대" || x == "근대" || x == "현대"){ window.location.href = "service.html"; }
        else if(x == "로맨스멜로" || x == "로맨스" || x == "멜로"){ window.location.href = "service1.html"; }
        else if(x == "호러스릴러" || x == "호러" || x == "스릴" || x == "공포"){ window.location.href = "service2.html"; }
        else if(x == "액션느와르" || x == "액션" || x == "느와르"){ window.location.href = "service3.html"; }
        else if(x == "사극역사" || x == "사극" || x == "역사"){ window.location.href = "service4.html"; }

        if(x == "힐링" || x == "힐링여행" || x == "휴식"){ window.location.href = "service9.html"; }
        else if(x == "문화공간" || x == "공간" || x == "문화" || x == "실내"){ window.location.href = "service10.html"; }
        else if(x == "레트로" || x == "옛날" || x == "고전" || x == "낡은"){ window.location.href = "service11.html" }
        else if(x == "이국적" || x == "이국" || x == "이색적" || x == "이색" || x == "외국" || x == "해외"){ window.location.href = "service12.html"; }
        else if(x == "활동적" || x == "활동" || x == "운동" || x == "여행"){ window.location.href = "service13.html"; }

    }
    